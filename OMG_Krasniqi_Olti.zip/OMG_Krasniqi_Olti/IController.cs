﻿using System.Windows.Forms;

internal class IController
{
private int model:IModel
private int view:IView

public int Controller()
public int setMode(Model:IModel)
public int setView(View:IView)

public int ggTBerechnen(Zahl1:int,Zahl2:int)
}