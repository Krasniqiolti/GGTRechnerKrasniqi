﻿using System.Windows.Forms;

internal class IModel
{
    private int view:IView
    private int controller:IController
    
    public int Model()
    public int setView(View:IView)
    public int setController(controller:IController)
}
