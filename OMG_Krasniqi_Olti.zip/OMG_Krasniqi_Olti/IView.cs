﻿using System.Runtime.Remoting.Channels;

internal class IView
{
    private int model:IModel;
    private int controller:IController
    private int labelZahl1:Label
    private int labelZahl2:Label
    private int labelGGT:Label
    public int buttonGgTBerechnen_Click(IChannelSender:object,e:EventArgs)
}